package phase_2;
interface Iscreen {

    public void displayFeatures(int userId);
}

